console.log('----------------------------------Activity 1-----------------------------------------------')
console.log('Print "Helllo World"')
let msg4 = "Hello World";
console.log(msg4);


console.log('--------------------------------------Activity 2-------------------------------------------')
console.log('Print that the number is a leap year or not.  ')
function Leapyear(number) {
  let year = number;
  let answer;
  if ((year %4 ==0 && year%100 !=0 ) || year %400 ==0)
  {
      answer = "Yes, It is a Leap Year"+number;
  }
  else {
  
      answer = "No, It is not a Leap Year"+number;
  
  }
  
  console.log(answer);
   }
  
  Leapyear(1997);


console.log('----------------------------------Activity 5-----------------------------------------------')
console.log('Reverse a string ')

let reversestring = (string) => string.split("").reverse().join('');
console.log(reversestring("Shubhanshu"));



console.log('------------------------------------Activity 6---------------------------------------------')
console.log('Triangle is equilateral, isosceles, or scalene')

let num = (a:Number,b:Number,c:Number):void =>
{
  if (a==b && b==c)

  {
console.log("This Triangle is an Equilateral triangle");
  }

  else if ((a==b && b!=c ) || (a!=b && c==a) || (c==b && c!=a))
  {
 console.log("This triangle is an Isosceles Triangle");
  }

  else if (a!=b && b!=c && c!=a)
{

    console.log("This triangle is an Scalene Triangle");
}

}

num(1,2,3);

console.log('------------------------------------Activity 7---------------------------------------------')
console.log('Armstrong number')
let armstrng = (num1:number) =>
{
 return new Promise(function(resolve,reject){

    if(num1==0)
    {
reject("invalid number.")        ;
    }

    let a1: number=0;
    let b: number=0;
    let temp:number=num1;
    var check=num1.toString().length;
    while(temp>0)
        {
            b=temp%10;
            temp=Math.floor(temp/10);
           // temp=b + a1*a1*a1;
            a1=a1+Math.pow(b,check);
        }   
    if(a1==num1)
        {
         
      return  resolve(num1+ " is an Armstrong No.");
        }
    else
        {
            return  resolve(num1+ " is Not Armstrong No.");
        }
})
}
armstrng(2233).then(success,failure);
function success(msg2)
{
console.log(msg2);    
}
function failure(msg3)
{
console.log(msg3);    
}
console.log('---------------------------------------------------------------------------------')