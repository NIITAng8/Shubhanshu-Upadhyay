let age= new Map();  
age.set("Years", 2314530000);  
age.set("Months", 345859494);  
age.set("Days", 2456000);  
age.set("Hours", 216000);  
age.set("Minutes", 3600);  
age.set("Seconds", 60);  


var agemap = function (Infoage) {
    console.log('Input seconds are : '+ Infoage.toString())
    return Math.floor(Infoage / age.get("Years")) + ' Years ' +
        Math.floor((Infoage % age.get("Years")) / age.get("Months")) + ' Months ' +
        Math.floor(((Infoage % age.get("Years") % age.get("Months"))) / age.get("Days")) + ' Days ' +
        Math.floor((((Infoage % age.get("Years") % age.get("Months")) % age.get("Days"))) / age.get("Hours")) + ' Hours ' +
        Math.floor(((((Infoage % age.get("Years") % age.get("Months")) % age.get("Days")) % age.get("Hours"))) / age.get("Minutes")) + ' Minutes ' +
        Math.floor((((((Infoage % age.get("Years") % age.get("Months")) % age.get("Days")) % age.get("Hours")) % age.get("Minutes"))) / age.get("Seconds")) + ' Seconds ';
};
console.log(agemap(74992640000)); 
