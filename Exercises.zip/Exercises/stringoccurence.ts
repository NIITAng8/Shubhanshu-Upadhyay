let input = 'Welcome To the World';
let words = input.trim().split(' ');
let wordsMap  = new Map();
let createWordMap = (words) => {   
  words.forEach((words) => {(wordsMap.hasOwnProperty(words)) ? wordsMap[words]++ : wordsMap[words] = 1;});
  return wordsMap;
};
let wordsCount = createWordMap(words);
console.log(wordsCount);